# RoboCasa Integration with OpenPI

This directory contains the integration code for running OpenPI policies on RoboCasa kitchen simulation tasks.

## Prerequisites

1. **RoboCasa Environment**: Make sure RoboCasa is installed in your target environment (`/home/luowen/Programing/RHOS/robocasa`).
   ```bash
   cd /home/luowen/Programing/RHOS/robocasa
   pip install -e .
   ```

2. **OpenPI Policy Server**: You need a running OpenPI policy server.

## Installation

### Step 1: Setup in RoboCasa Environment

```bash
# Navigate to your RoboCasa environment
cd /home/luowen/Programing/RHOS/robocasa

# Install required dependencies
pip install numpy>=1.21.0 einops>=0.6.0 imageio>=2.9.0 tqdm>=4.62.0 tyro>=0.5.0

# Install OpenPI client
pip install -e /home/luowen/Programing/RHOS/openpi/packages/openpi-client

# Copy integration files
cp -r /home/luowen/Programing/RHOS/openpi/examples/robocasa ./robocasa_openpi
```

### Step 2: Setup Integration Script

```bash
cd /home/luowen/Programing/RHOS/robocasa
chmod +x /home/luowen/Programing/RHOS/openpi/examples/robocasa/setup_integration.sh
/home/luowen/Programing/RHOS/openpi/examples/robocasa/setup_integration.sh
```

## Usage

### Method 1: Using the Quick Start Script

```bash
# Step 1: Start OpenPI Policy Server (in OpenPI directory)
cd /home/luowen/Programing/RHOS/openpi
uv run scripts/serve_policy.py policy:checkpoint --policy.config=pi0_fast_libero --policy.dir=checkpoints/pi0_fast_libero/my_experiment/20000

# Step 2: Run RoboCasa Client (in another terminal)
cd /home/luowen/Programing/RHOS/robocasa/robocasa_openpi
./quick_start.sh
```

### Method 2: Manual Execution

```bash
# Step 1: Start OpenPI Policy Server
cd /home/luowen/Programing/RHOS/openpi
uv run scripts/serve_policy.py policy:checkpoint --policy.config=pi0_fast_libero --policy.dir=checkpoints/pi0_fast_libero/my_experiment/20000

# Step 2: Run RoboCasa Client
cd /home/luowen/Programing/RHOS/robocasa/robocasa_openpi

# Set environment variables
export PYTHONPATH="/home/luowen/Programing/RHOS/robocasa:/home/luowen/Programing/RHOS/openpi/packages/openpi-client/src:$PYTHONPATH"

# Run with default settings
python main.py

# Or run with custom settings
python main.py --task_name PnPCounterToCab --robots PandaOmron --num_episodes 3 --action_horizon 10
```

### Available Arguments

- `--host`: Policy server host (default: "0.0.0.0")
- `--port`: Policy server port (default: 8000)
- `--task_name`: RoboCasa task name (default: "PnPCounterToCab")
- `--robots`: Robot type (default: "PandaOmron")
- `--action_horizon`: Action chunking horizon (default: 10)
- `--num_episodes`: Number of episodes to run (default: 1)
- `--max_episode_steps`: Maximum steps per episode (default: 500)
- `--out_dir`: Output directory for videos (default: "data/robocasa/videos")
- `--seed`: Random seed (default: 0)

### Example Commands

```bash
# Run with different task
python main.py --task_name "PnPCabToCounter" --num_episodes 3

# Run with longer episodes
python main.py --max_episode_steps 1000 --action_horizon 15

# Run multiple episodes for evaluation
python main.py --num_episodes 10 --out_dir ./evaluation_videos
```

## Supported RoboCasa Tasks

The integration supports any RoboCasa task. Some common tasks include:
- `PnPCounterToCab`: Pick and place from counter to cabinet
- `PnPCabToCounter`: Pick and place from cabinet to counter  
- `OpenSingleDoor`: Open a single cabinet door
- `CloseSingleDoor`: Close a single cabinet door
- `TurnOnSinkFaucet`: Turn on the sink faucet
- `TurnOffSinkFaucet`: Turn off the sink faucet

To see all available tasks:
```python
from robocasa.environments import ALL_KITCHEN_ENVIRONMENTS
print(list(ALL_KITCHEN_ENVIRONMENTS))
```

## Architecture Overview

```
OpenPI Policy Server (openpi/) <--WebSocket--> RoboCasa Client (robocasa/)
                |                                        |
        [Policy Inference]                    [RoboCasa Environment]
                |                                        |
        [Action Generation]                    [Robot Simulation]
```

### Key Components

1. **`env.py`**: RoboCasa environment adapter that implements the OpenPI `Environment` interface
2. **`main.py`**: Main script that sets up the runtime loop and connects to the policy server  
3. **`saver.py`**: Video saver for recording episodes
4. **WebSocket Communication**: Handles observation/action exchange between environments

### Observation Format

The RoboCasa environment provides observations in the following format:
```python
{
    "state": np.array([...]),  # Robot joint positions + gripper state (7 DOF for Panda)
    "images": {
        "cam_high": np.array([3, 224, 224])  # Camera image in CHW format
    }
}
```

### Action Format

Actions are expected in the format:
```python
{
    "actions": np.array([...])  # Robot joint positions/velocities (7 DOF for Panda)
}
```

## Troubleshooting

### Common Issues

1. **Connection Refused**: Make sure the OpenPI policy server is running and accessible on the specified host/port

2. **Import Errors**: 
   ```bash
   # Make sure RoboCasa is installed
   pip install -e /home/luowen/Programing/RHOS/robocasa
   
   # Make sure OpenPI client is installed  
   pip install -e /home/luowen/Programing/RHOS/openpi/packages/openpi-client
   ```

3. **Task Not Found**: Check that the specified task name exists in RoboCasa
   ```python
   from robocasa.environments import ALL_KITCHEN_ENVIRONMENTS
   print("Available tasks:", list(ALL_KITCHEN_ENVIRONMENTS))
   ```

4. **Camera/Observation Issues**: RoboCasa uses different camera names than other environments. The adapter automatically detects available cameras.

5. **Action Dimension Mismatch**: Different robots have different action dimensions:
   - PandaOmron: 7 DOF (6 arm joints + 1 gripper)
   - Check your policy's expected action dimension

### Performance Tuning

- **Reduce Episode Length**: Use `--max_episode_steps 200` for faster testing
- **Adjust Action Horizon**: Try `--action_horizon 5` for more reactive control or `--action_horizon 20` for smoother trajectories  
- **Control Frequency**: The runtime runs at 50Hz by default, matching other OpenPI examples

### Debugging

Enable detailed logging:
```bash
export PYTHONPATH="/home/luowen/Programing/RHOS/robocasa:/home/luowen/Programing/RHOS/openpi/packages/openpi-client/src:$PYTHONPATH"
python -c "import logging; logging.basicConfig(level=logging.DEBUG)" main.py --num_episodes 1
```

## Customization

### Adding New Tasks
You can easily test different RoboCasa tasks by changing the `task_name` parameter.

### Modifying Observation/Action Spaces
Edit the `_convert_observation` method in `env.py` to customize how observations are processed.

### Adding Custom Cameras
Modify the camera setup in the environment initialization to use different camera views.

### Custom Robot Configurations
Change the `robots` parameter to use different robot types supported by RoboCasa.
