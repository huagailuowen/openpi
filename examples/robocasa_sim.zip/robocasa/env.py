"""RoboCasa environment adapter for OpenPI."""

from typing import Dict, Any, Optional
import numpy as np
import einops
from openpi_client import image_tools
from openpi_client.runtime import environment as _environment
from typing_extensions import override

# Import robocasa dependencies
try:
    import robocasa
    from robocasa.environments import ALL_KITCHEN_ENVIRONMENTS
    from robocasa.utils.env_utils import create_env
    import robosuite as suite
    from robosuite.controllers import load_composite_controller_config
except ImportError as e:
    raise ImportError(
        "RoboCasa not found. Please install RoboCasa in your environment. "
        "See: https://github.com/robocasa/robocasa"
    ) from e


class RoboCasaEnvironment(_environment.Environment):
    """An environment adapter for RoboCasa kitchen tasks."""

    def __init__(
        self,
        task_name: str = "PnPCounterToCab",
        robots: str = "PandaOmron",
        camera_names: list = None,
        camera_widths: int = 128,
        camera_heights: int = 128,
        render_height: int = 224,
        render_width: int = 224,
        horizon: int = 500,
        seed: Optional[int] = None,
        **env_kwargs
    ) -> None:
        """
        Initialize RoboCasa environment.
        
        Args:
            task_name: Name of the RoboCasa task (e.g., "PnPCounterToCab")
            robots: Robot type to use
            camera_names: List of camera names for observations
            camera_widths: Width for camera observations
            camera_heights: Height for camera observations  
            render_height: Height for image rendering to policy
            render_width: Width for image rendering to policy
            horizon: Maximum episode length
            seed: Random seed
            **env_kwargs: Additional environment arguments
        """
        self.task_name = task_name
        self.render_height = render_height
        self.render_width = render_width
        self.horizon = horizon
        
        # Default camera setup - use agentview cameras like in documentation
        if camera_names is None:
            camera_names = [
                "robot0_agentview_left",
                "robot0_agentview_right", 
                "robot0_eye_in_hand",
            ]
        self.camera_names = camera_names
        
        # Create the RoboCasa environment using their utility function
        self._env = create_env(
            env_name=task_name,
            robots=robots,
            camera_names=camera_names,
            camera_widths=camera_widths,
            camera_heights=camera_heights,
            seed=seed,
            render_onscreen=False,  # We'll handle rendering separately
            **env_kwargs
        )
        
        self._last_obs = None
        self._episode_steps = 0
        self._done = False

    @override
    def reset(self) -> None:
        """Reset the environment to its initial state."""
        raw_obs = self._env.reset()
        self._last_obs = self._convert_observation(raw_obs)
        self._episode_steps = 0
        self._done = False

    @override
    def is_episode_complete(self) -> bool:
        """Check if the episode is complete."""
        return self._done or self._episode_steps >= self.horizon

    @override
    def get_observation(self) -> dict:
        """Get the current observation."""
        if self._last_obs is None:
            raise RuntimeError("Observation is not set. Call reset() first.")
        return self._last_obs

    @override
    def apply_action(self, action: dict) -> None:
        """Apply an action to the environment."""
        # Extract actions from the action dict
        robot_actions = action["actions"]
        
        # Step the environment
        raw_obs, reward, done, info = self._env.step(robot_actions)
        
        # Convert observation to OpenPI format
        self._last_obs = self._convert_observation(raw_obs)
        self._episode_steps += 1
        self._done = done

    def _convert_observation(self, raw_obs: dict) -> dict:
        """Convert RoboCasa observation to OpenPI format."""
        # Extract robot state (joint positions + gripper)
        robot_states = []
        
        # Get robot joint positions (7 DOF for Panda: 6 arm joints + 1 gripper)
        if "robot0_joint_pos" in raw_obs:
            robot_states.extend(raw_obs["robot0_joint_pos"])
        elif "robot0_joint_pos_cos" in raw_obs and "robot0_joint_pos_sin" in raw_obs:
            # Handle joint positions in cos/sin format
            cos_vals = raw_obs["robot0_joint_pos_cos"]
            sin_vals = raw_obs["robot0_joint_pos_sin"]
            joint_angles = np.arctan2(sin_vals, cos_vals)
            robot_states.extend(joint_angles)
        
        # Get gripper state if available
        if "robot0_gripper_qpos" in raw_obs:
            robot_states.extend(raw_obs["robot0_gripper_qpos"])
        elif "robot0_eef_pos" in raw_obs and "robot0_eef_quat" in raw_obs:
            # If gripper joint pos not available, use end-effector pose as proxy
            robot_states.extend(raw_obs["robot0_eef_pos"])
            robot_states.extend(raw_obs["robot0_eef_quat"])
            
        state = np.array(robot_states, dtype=np.float32)
        
        # Process camera images - use the first available camera
        images = {}
        
        # Try to find the main camera image
        main_camera = None
        if f"{self.camera_names[0]}_image" in raw_obs:
            main_camera = self.camera_names[0]
        else:
            # Fallback: find any available camera
            for cam_name in self.camera_names:
                if f"{cam_name}_image" in raw_obs:
                    main_camera = cam_name
                    break
        
        if main_camera:
            img = raw_obs[f"{main_camera}_image"]
            
            # Convert to uint8 and resize like aloha_sim
            img = image_tools.convert_to_uint8(
                image_tools.resize_with_pad(img, self.render_height, self.render_width)
            )
            
            # Convert from [H, W, C] to [C, H, W] like aloha_sim
            img = einops.rearrange(img, "h w c -> c h w")
            images["cam_high"] = img  # Use standardized key name like aloha_sim
        
        return {
            "state": state,
            "images": images,
        }

    def get_env_info(self) -> dict:
        """Get environment information."""
        return {
            "task_name": self.task_name,
            "action_dim": len(self._env.action_spec[0]),  # Get action dimension from env
            "action_spec": (self._env.action_spec[0], self._env.action_spec[1]),  # (low, high)
            "horizon": self.horizon,
            "cameras": self.camera_names,
        }
