"""Main script for running OpenPI policy on RoboCasa tasks."""

import dataclasses
import logging
import pathlib
from typing import Optional

import env as _env
from openpi_client import action_chunk_broker
from openpi_client import websocket_client_policy as _websocket_client_policy
from openpi_client.runtime import runtime as _runtime
from openpi_client.runtime.agents import policy_agent as _policy_agent
import saver as _saver
import tyro


@dataclasses.dataclass
class Args:
    """Arguments for running RoboCasa with OpenPI."""
    
    # Output directory
    out_dir: pathlib.Path = pathlib.Path("data/robocasa/videos")
    
    # Policy server connection
    host: str = "0.0.0.0"
    port: int = 8000
    
    # RoboCasa environment settings
    task_name: str = "PnPCounterToCab"  # Default task from RoboCasa
    robots: str = "PandaOmron"  # Default robot from RoboCasa examples
    
    # Action chunking settings - use similar values to aloha_sim
    action_horizon: int = 10
    
    # Episode settings
    num_episodes: int = 1
    max_episode_steps: int = 500
    
    # Display settings
    display: bool = False
    
    # Seed
    seed: Optional[int] = 0


def main(args: Args) -> None:
    """Main function to run RoboCasa evaluation with OpenPI."""
    
    # Create output directory  
    args.out_dir.mkdir(parents=True, exist_ok=True)
    
    # Connect to policy server
    ws_client_policy = _websocket_client_policy.WebsocketClientPolicy(
        host=args.host,
        port=args.port,
    )
    logging.info(f"Connected to policy server. Metadata: {ws_client_policy.get_server_metadata()}")
    
    # Create RoboCasa environment
    robocasa_env = _env.RoboCasaEnvironment(
        task_name=args.task_name,
        robots=args.robots,
        horizon=args.max_episode_steps,
        seed=args.seed,
    )
    
    logging.info(f"Created RoboCasa environment: {robocasa_env.get_env_info()}")
    
    # Create runtime with action chunking (same pattern as aloha_sim)
    runtime = _runtime.Runtime(
        environment=robocasa_env,
        agent=_policy_agent.PolicyAgent(
            policy=action_chunk_broker.ActionChunkBroker(
                policy=ws_client_policy,
                action_horizon=args.action_horizon,
            )
        ),
        subscribers=[
            _saver.VideoSaver(args.out_dir),
        ],
        max_hz=50,  # Control frequency like aloha_sim
        num_episodes=args.num_episodes,
        max_episode_steps=args.max_episode_steps,
    )
    
    logging.info(f"Starting evaluation for {args.num_episodes} episodes...")
    
    # Run evaluation
    runtime.run()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, force=True)
    tyro.cli(main)
