#!/bin/bash

# RoboCasa OpenPI Integration Setup Script
# This script helps set up and run OpenPI with RoboCasa

set -e

echo "=== RoboCasa OpenPI Integration Setup ==="

# Configuration
OPENPI_DIR="/home/luowen/Programing/RHOS/openpi"
ROBOCASA_DIR="/home/luowen/Programing/RHOS/robocasa"
INTEGRATION_DIR="$ROBOCASA_DIR/robocasa_openpi"

# Check if directories exist
if [ ! -d "$OPENPI_DIR" ]; then
    echo "Error: OpenPI directory not found at $OPENPI_DIR"
    exit 1
fi

if [ ! -d "$ROBOCASA_DIR" ]; then
    echo "Error: RoboCasa directory not found at $ROBOCASA_DIR"
    exit 1
fi

echo "✓ Found OpenPI at: $OPENPI_DIR"
echo "✓ Found RoboCasa at: $ROBOCASA_DIR"

# Copy integration files to RoboCasa directory
echo "📁 Copying integration files..."
mkdir -p "$INTEGRATION_DIR"
cp -r "$OPENPI_DIR/examples/robocasa/"* "$INTEGRATION_DIR/"

echo "✓ Integration files copied to: $INTEGRATION_DIR"

# Create activation script that handles Python path correctly
cat > "$INTEGRATION_DIR/activate_and_run.py" << 'EOF'
#!/usr/bin/env python3
"""Activation script for RoboCasa OpenPI integration."""

import sys
import os
from pathlib import Path

def setup_paths():
    """Setup Python paths for the integration."""
    # Add paths
    robocasa_dir = Path("/home/luowen/Programing/RHOS/robocasa")
    openpi_client_dir = Path("/home/luowen/Programing/RHOS/openpi/packages/openpi-client/src")
    current_dir = Path(__file__).parent

    # Insert paths at the beginning so they take precedence
    sys.path.insert(0, str(current_dir))
    sys.path.insert(0, str(robocasa_dir))
    sys.path.insert(0, str(openpi_client_dir))

    # Set environment variables
    current_pythonpath = os.environ.get('PYTHONPATH', '')
    new_pythonpath = f"{current_dir}:{robocasa_dir}:{openpi_client_dir}:{current_pythonpath}"
    os.environ["PYTHONPATH"] = new_pythonpath

def main():
    """Main function to run the integration."""
    setup_paths()
    
    # Import and run after setting up paths
    try:
        from main import main as main_func, Args
        import tyro
        
        print("🚀 Starting RoboCasa OpenPI Integration...")
        print("📍 Make sure OpenPI policy server is running!")
        print("   Example: uv run scripts/serve_policy.py policy:checkpoint --policy.config=pi0_fast_libero --policy.dir=checkpoints/pi0_fast_libero/my_experiment/20000")
        print()
        
        tyro.cli(main_func)
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Make sure all dependencies are installed:")
        print("  pip install numpy einops imageio tqdm tyro")
        print("  pip install -e /home/luowen/Programing/RHOS/openpi/packages/openpi-client")
        print("  pip install -e /home/luowen/Programing/RHOS/robocasa")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Runtime error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
EOF

chmod +x "$INTEGRATION_DIR/activate_and_run.py"

# Create quick start script
cat > "$INTEGRATION_DIR/quick_start.sh" << 'EOF'
#!/bin/bash

echo "🏃 Quick Start: RoboCasa + OpenPI"
echo "=================================="
echo ""

# Check if policy server is running
echo "🔍 Checking if OpenPI policy server is running..."
if ! curl -s http://localhost:8000/healthz > /dev/null 2>&1; then
    echo "⚠️  OpenPI policy server not detected on localhost:8000"
    echo ""
    echo "1️⃣  Please start OpenPI Policy Server first:"
    echo "   cd /home/luowen/Programing/RHOS/openpi"
    echo "   uv run scripts/serve_policy.py policy:checkpoint --policy.config=pi0_fast_libero --policy.dir=checkpoints/pi0_fast_libero/my_experiment/20000"
    echo ""
    echo "2️⃣  Then run this script again"
    exit 1
fi

echo "✅ Policy server is running!"
echo ""
echo "2️⃣  Starting RoboCasa Client..."
echo "   Current directory: $(pwd)"
echo ""

# Navigate to the integration directory
cd "$(dirname "$0")"

# Run the integration
python3 activate_and_run.py "$@"
EOF

chmod +x "$INTEGRATION_DIR/quick_start.sh"

echo ""
echo "🎉 Setup complete!"
echo ""
echo "📋 Next Steps:"
echo "=============="
echo ""
echo "1. Start OpenPI policy server:"
echo "   cd $OPENPI_DIR"
echo "   uv run scripts/serve_policy.py policy:checkpoint --policy.config=pi0_fast_libero --policy.dir=checkpoints/pi0_fast_libero/my_experiment/20000"
echo ""
echo "2. In another terminal, run RoboCasa client:"
echo "   cd $INTEGRATION_DIR"
echo "   ./quick_start.sh"
echo ""
echo "📚 Available commands:"
echo "   ./quick_start.sh --help                          # Show all options"
echo "   ./quick_start.sh --task_name PnPCounterToCab     # Run specific task"
echo "   ./quick_start.sh --num_episodes 5               # Run multiple episodes"
echo "   ./quick_start.sh --action_horizon 15            # Adjust action chunking"
echo ""
echo "🔧 Manual execution:"
echo "   cd $INTEGRATION_DIR"
echo "   python3 activate_and_run.py [options]"
echo ""
echo "📖 For more details, see: $INTEGRATION_DIR/README.md"
